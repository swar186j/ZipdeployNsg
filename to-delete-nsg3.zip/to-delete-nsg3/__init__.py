import logging
import json
import os
from azure.storage.blob import BlobServiceClient
import azure.functions as func
import requests
# Initialize BlobServiceClient
blob_service_client = BlobServiceClient.from_connection_string(os.getenv("AzureWebJobsStorage"))
app = func.FunctionApp()
@app.function_name(name="to-delete-nsg3")
@app.blob_trigger(
    arg_name="blob",
    path="insights-logs-networksecuritygroupflowevent/{resourceId}/y={year}/m={month}/d={day}/h={hour}/m={minute}/macAddress={macAddress}/PT1H.json",
    connection="AzureWebJobsStorage"
)
def main(blob: func.InputStream):
    logging.info(f"Blob trigger function processed blob \n Name: {blob.name}")
    try:
        print("=================================")
        # Extract container and blob names from URI
        container_name = blob.uri.split('/')[3]
        blob_name = '/'.join(blob.uri.split('/')[4:])
        logging.info(f"Container name: {container_name}")
        logging.info(f"Blob name: {blob_name}")
        # Checkpoint blob name - same directory as the JSON blob
        checkpoint_blob_name = f"{blob_name}_checkpoint"
        logging.info(f"Checkpoint blob name: {checkpoint_blob_name}")
        # Read the checkpoint (if exists)
        checkpoint_blob_client = blob_service_client.get_blob_client(container=container_name, blob=checkpoint_blob_name)
        start_index = 0
        if checkpoint_blob_client.exists():
            checkpoint_blob = checkpoint_blob_client.download_blob().readall()
            start_index = int(checkpoint_blob.decode('utf-8'))
            logging.info(f"Starting index from checkpoint: {start_index}")
        else:
            logging.info("No checkpoint found. Starting from index: 0")
        # Read the JSON blob
        blob_content = blob.read().decode('utf-8')
        logs = json.loads(blob_content)
        logging.info(f"Total logs read: {len(logs)}")
        # Process new logs starting from the checkpoint
        new_logs = logs[start_index:]
        for log in new_logs:
            process_log(log)
            start_index += 1
        # Update the checkpoint
        checkpoint_blob_client.upload_blob(str(start_index), overwrite=True)
        logging.info(f"Checkpoint updated to index: {start_index}")
    except Exception as e:
        logging.error(f"Error processing blob: {e}")
def process_log(log):
    # Implement your log processing logic here
    logging.info(f"Processing log: {log}")